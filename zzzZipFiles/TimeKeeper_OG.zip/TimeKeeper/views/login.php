<html>
	<head>
		<link type="text/css" rel="stylesheet" href="assets/css/loginStyle.css"/>
		<title> MLHC Login </title>

	</head>

	<body>
		<div id="header1"> </div>
		<div id="header2"> </div>
		<div id="header3"> </div>
		<div id="logo"> <center> <a href="http://mlhc.com" target="_blank"> <img src="assets/images/MLHC.png"> </a> </center> </div>
		<form action="" method="post">
			<center>
				<br>
				<font size="5"> Username: </font>
				<input id="username" type="text" name="username">
				<br>
				<br>
				<font size="5"> Password: </font>
				<input id="password" type="password" name="password">
				<br>
				<font id="fpword"> <a href="forgotPassword.php"> Forgot password?</a> </font>
				<input type="Submit" value='Login' style="font-size:1em">
			</center>
		</form>
	</body>
</html>
