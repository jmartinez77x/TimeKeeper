<h1><?php echo $welcome; ?></h1>
<p>yonas</p>
