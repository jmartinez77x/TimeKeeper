<html>
	<head>
		<link type="text/css" rel="stylesheet" href="assets/css/loginStyle.css"/>
		<title> MLHC Forgot Password </title>

	</head>

	<body>
		<div id="header1"> </div>
		<div id="header2"> </div>
		<div id="header3"> </div>
		<div id="logo"> <center> <a href="http://mlhc.com" target="_blank"> <img src="assets/images/MLHC.png"> </a> </center> </div>
			<center>
				<p> Please see your supervisor or contact the system administrator. </p>
			</center>
		</form>
	</body>
</html>
